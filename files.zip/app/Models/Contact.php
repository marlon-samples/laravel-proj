<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    use HasFactory;
    
    protected $dates = ['created_at', 'updated_at', 'deleted_at'];

    protected $casts = [
        'created_at' => 'date:M d, Y',
        'updated_at' => 'date:M d, Y',
        'deleted_at' => 'date:M d, Y',
    ];

    public function mark()
    {
        return $this->hasOne(Mark::class, 'id', 'mark_id');
    }

    public function tab_count($id)
    {
        return Contact::where('mark_id', $id)->count();
    }

    public function contactList($id)
    {
        return Contact::with('mark')->where('mark_id', $id)->get();
    }

    public function new_contact($request)
    {
        $new = new Contact;
        $new->name = $request['recipient'];
        $new->informations = $request['informations'];
        $new->remarks = $request['init_remarks'];
        $new->mark_id = 1;
        $new->save();

    }
}
