<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;

use App\Models\Contact;

class DashboardController extends Controller
{
    public function __construct(Contact $contacts) 
    {
        $this->contacts = $contacts;
    }

    public function dashboard()
    {
        return Inertia::render('Dashboard',[
            'new_cnt' => $this->contacts->tab_count(1),
            'contacted_cnt' => $this->contacts->tab_count(2),
            'callback_cnt' => $this->contacts->tab_count(3),
            'closed_cnt' => $this->contacts->tab_count(4)
        ]);
    }
}
