<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;

use App\Models\Role;
use App\Models\Mark;

class SettingController extends Controller
{
    public function __construct(Role $roles, Mark $marks) 
    {
        $this->roles = $roles;
        $this->marks = $marks;
    }

    public function roles()
    {
        return Inertia::render('Settings',[
            'roles' => $this->roles->roles(),
            'isRoles' => true,
            'isMark' => false
        ]);
    }

    public function marks()
    {
        return Inertia::render('Marks',[
            'marks' => $this->marks->marks(),
            'isRoles' => false,
            'isMark' => true
        ]);
    }
    
}
