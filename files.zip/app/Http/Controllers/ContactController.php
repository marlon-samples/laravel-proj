<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Inertia\Inertia;

use App\Models\Contact;

class ContactController extends Controller
{
    public function __construct(Contact $contacts) 
    {
        $this->contacts = $contacts;
    }

    public function contacts()
    {
        return Inertia::render('Contacts',[
            'new_cnt' => $this->contacts->tab_count(1),
            'contacted_cnt' => $this->contacts->tab_count(2),
            'callback_cnt' => $this->contacts->tab_count(3),
            'closed_cnt' => $this->contacts->tab_count(4),
            'contacts' => $this->contacts->contactList(1),
            'contacteds' => $this->contacts->contactList(2),
            'callbacks' => $this->contacts->contactList(3),
            'closeds' => $this->contacts->contactList(4),
        ]);
    }

    public function newContact() 
    {
        $this->contacts->new_contact(\Request::all());  
        return Redirect::route('contacts')->with('success', 'User created.');   
    }
}
