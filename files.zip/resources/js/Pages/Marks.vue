<template>
    <Head title="Contacts" />

    <BreezeAuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Settings
            </h2>
        </template>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <div class="row align-items-start">
                            <div class="col-4">
                                <div class="d-flex flex-column flex-shrink-0 p-3 bg-light" style="width: 280px;">
                                    <a href="/settings" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
                                        <span class="fs-4">Menu {{active_menu_two}}</span>
                                    </a>
                                    <hr>
                                    <ul class="nav nav-pills flex-column mb-auto">
                                        <li class="nav-item">
                                            <a :href="route('roles')"
                                                class="nav-link"
                                                v-bind:class="{ active: isRoles, 'link-dark': isMark }"
                                                aria-current="page">
                                                <i class="bi bi-person-check"></i>
                                                Roles
                                            </a>
                                        </li>
                                        <li>
                                            <a :href="route('marks')"
                                                class="nav-link"
                                                v-bind:class="{ active: isMark, 'link-dark': isRoles }"
                                            >
                                                <i class="bi bi-bookmarks"></i>
                                                Marks
                                            </a>
                                        </li>
                                    </ul>
                                    <hr>
                                    <div class="dropdown">
                                    <a href="#" class="d-flex align-items-center link-dark text-decoration-none dropdown-toggle" id="dropdownUser2" data-bs-toggle="dropdown" aria-expanded="false">
                                        <img src="https://github.com/mdo.png" alt="" width="32" height="32" class="rounded-circle me-2">
                                        <strong>{{ $page.props.auth.user.name }}</strong>
                                    </a>
                                    <ul class="dropdown-menu text-small shadow" aria-labelledby="dropdownUser2">
                                        <li>
                                            <BreezeResponsiveNavLink :href="route('logout')" method="post" as="button">
                                                Log Out
                                            </BreezeResponsiveNavLink>
                                        </li>
                                    </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="mark in marks" :key="mark.id">
                                            <th scope="row">{{mark.id}}</th>
                                            <td>{{mark.name}}</td>
                                            <td>
                                                <button type="button" class="btn btn-outline-success btn-sm ms-1"><i class="bi bi-eye-fill"></i> Edit</button>
                                                <button type="button" class="btn btn-outline-danger btn-sm ms-1"><i class="bi bi-eraser-fill"></i> Remove</button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </BreezeAuthenticatedLayout>
</template>

<script>
import BreezeNavLink from '@/Components/NavLink.vue'
import BreezeResponsiveNavLink from '@/Components/ResponsiveNavLink.vue'
import BreezeAuthenticatedLayout from '@/Layouts/Authenticated.vue'
import { Head } from '@inertiajs/inertia-vue3';

export default {
    components: {
        BreezeNavLink,
        BreezeResponsiveNavLink,
        BreezeAuthenticatedLayout,
        Head,
    },
    props: {
        marks: Array,
        active_menu_two: String, 
        isRoles: Boolean,
        isMark: Boolean,
    },
}
</script>
