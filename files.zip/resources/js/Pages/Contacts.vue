<template>
    <Head title="Contacts" />

    <BreezeAuthenticatedLayout>
        <template #header>
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Contacts
            </h2>
        </template>

        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <button type="button" data-bs-toggle="modal" @click="modal_open" data-bs-target="#newContactModal" class="btn btn-success btn-lg ms-1"><i class="bi bi-plus"></i> Add New</button>
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 bg-white border-b border-gray-200">
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">                                
                                <button class="nav-link active" id="new-tab" @click="new_ontacts" data-bs-toggle="tab" data-bs-target="#new" type="button" role="tab" aria-controls="home" aria-selected="true">
                                    New Contacts (<b>{{new_cnt}}</b>)                               
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="contacted-tab" @click="contacted" data-bs-toggle="tab" data-bs-target="#contacted" type="button" role="tab" aria-controls="profile" aria-selected="false">
                                    Pending (<b>{{contacted_cnt}}</b>)   
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="Viewback-tab" @click="callback" data-bs-toggle="tab" data-bs-target="#Viewback" type="button" role="tab" aria-controls="contact" aria-selected="false">
                                    Callback (<b>{{callback_cnt}}</b>)   
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="closed-tab" @click="closed" data-bs-toggle="tab" data-bs-target="#closed" type="button" role="tab" aria-controls="contact" aria-selected="false">
                                    Closed (<b>{{closed_cnt}}</b>)   
                                </button>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="new" role="tabpanel" aria-labelledby="new-tab">
                                <h2>New Contacts List</h2> 
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Date Added</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="contact in contacts" :key="contact.id">
                                            <th scope="row">{{contact.id}}</th>
                                            <th scope="row">{{contact.name}}</th>
                                            <td>{{contact.created_at}}</td>
                                            <td><span class="badge bg-success">{{contact.mark.name}}</span></td>
                                            <td>
                                                <button type="button" data-bs-toggle="modal" data-bs-target="#viewContactModal" class="btn btn-outline-success btn-sm ms-1"><i class="bi bi-eye-fill"></i> View</button>
                                                <button type="button" class="btn btn-outline-info btn-sm ms-1"><i class="bi bi-pencil"></i> Edit</button>
                                                <button type="button" class="btn btn-outline-danger btn-sm ms-1"><i class="bi bi-eraser-fill"></i> Remove</button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>                                
                            </div>
                            <div class="tab-pane fade" id="contacted" role="tabpanel" aria-labelledby="contacted-tab">
                                <h2>Contacted Prospects</h2>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Date Added</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="contacted in contacteds" :key="contacted.id">
                                            <th scope="row">{{contacted.id}}</th>
                                            <th scope="row">{{contacted.name}}</th>
                                            <td>{{contacted.created_at}}</td>
                                            <td><span class="badge bg-success">{{contacted.mark.name}}</span></td>
                                            <td>
                                                <button type="button" class="btn btn-outline-success btn-sm ms-1"><i class="bi bi-eye-fill"></i> View</button>
                                                <button type="button" class="btn btn-outline-info btn-sm ms-1"><i class="bi bi-pencil"></i> Edit</button>
                                                <button type="button" class="btn btn-outline-danger btn-sm ms-1"><i class="bi bi-eraser-fill"></i> Remove</button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>                                                                                          
                            </div>
                            <div class="tab-pane fade" id="Viewback" role="tabpanel" aria-labelledby="Viewback-tab">
                                <h2>For Callback</h2>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Date Added</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="callback in callbacks" :key="callback.id">
                                            <th scope="row">{{callback.id}}</th>
                                            <th scope="row">{{callback.name}}</th>
                                            <td>{{callback.created_at}}</td>
                                            <td><span class="badge bg-success">{{callback.mark.name}}</span></td>
                                            <td>
                                                <button type="button" class="btn btn-outline-success btn-sm ms-1"><i class="bi bi-eye-fill"></i> View</button>
                                                <button type="button" class="btn btn-outline-info btn-sm ms-1"><i class="bi bi-pencil"></i> Edit</button>
                                                <button type="button" class="btn btn-outline-danger btn-sm ms-1"><i class="bi bi-eraser-fill"></i> Remove</button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>                                                                                          
                            </div>
                            <div class="tab-pane fade" id="closed" role="tabpanel" aria-labelledby="closed-tab">
                                <h2>Closed Prospects</h2>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Date Added</th>
                                            <th scope="col">Status</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="closed in closeds" :key="closed.id">
                                            <th scope="row">{{closed.id}}</th>
                                            <th scope="row">{{closed.name}}</th>
                                            <td>{{closed.created_at}}</td>
                                            <td><span class="badge bg-success">{{closed.mark.name}}</span></td>
                                            <td>
                                                <button type="button" class="btn btn-outline-success btn-sm ms-1"><i class="bi bi-eye-fill"></i> View</button>
                                                <button type="button" class="btn btn-outline-info btn-sm ms-1"><i class="bi bi-pencil"></i> Edit</button>
                                                <button type="button" class="btn btn-outline-danger btn-sm ms-1"><i class="bi bi-eraser-fill"></i> Remove</button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>                                                                                          
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Add -->
        <div class="modal fade" id="newContactModal" tabindex="-1" aria-labelledby="newContactModalModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newContactModalModalLabel">New Contact</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="mb-3">
                            <label for="recipient-name" class="col-form-label">Recipient:</label>
                            <input type="text" class="form-control" id="recipient" v-model="recipient">
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Informations:</label>
                            <editor
                                api-key="h2ejcrnvgywfvz72uusmfg5zj08tsl47gegqhqyf8j7kg681"
                                v-model="informations"
                                id="informations"
                                :init="{
                                    height: 300,
                                    menubar: false,
                                    plugins: [
                                    'advlist autolink lists link image charmap print preview anchor',
                                    'searchreplace visualblocks code fullscreen',
                                    'insertdatetime media table paste code help wordcount'
                                    ],
                                    toolbar:
                                    'undo redo | formatselect | bold italic backcolor | \
                                    alignleft aligncenter alignright alignjustify | \
                                    bullist numlist outdent indent | removeformat | help'
                                }"
                            />
                        </div>
                        <div class="mb-3">
                            <label for="message-text" class="col-form-label">Initial Remarks:</label>
                            <editor
                                api-key="h2ejcrnvgywfvz72uusmfg5zj08tsl47gegqhqyf8j7kg681"
                                v-model="init_remarks"
                                id="init_remarks"
                                :init="{
                                    height: 300,
                                    menubar: false,
                                    plugins: [
                                    'advlist autolink lists link image charmap print preview anchor',
                                    'searchreplace visualblocks code fullscreen',
                                    'insertdatetime media table paste code help wordcount'
                                    ],
                                    toolbar:
                                    'undo redo | formatselect | bold italic backcolor | \
                                    alignleft aligncenter alignright alignjustify | \
                                    bullist numlist outdent indent | removeformat | help'
                                }"
                            />
                        </div>
                    </form>                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" @click="modal_submit" class="btn btn-primary">Submit</button>
                </div>
                </div>
            </div>
        </div>
        <!-- Modal View -->
        <div class="modal fade" id="viewContactModal" tabindex="-1" aria-labelledby="viewContactModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewContactModalLabel">Contact Information</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-sm">
                                <form>
                                    <div class="mb-3">
                                        <label for="recipient-name" class="col-form-label">Recipient:</label>
                                        <input type="text" class="form-control" id="recipient" v-model="recipient">
                                    </div>
                                    <div class="mb-3">
                                        <label for="message-text" class="col-form-label">Informations:</label>
                                        <editor
                                            api-key="h2ejcrnvgywfvz72uusmfg5zj08tsl47gegqhqyf8j7kg681"
                                            v-model="informationsv"
                                            id="informationsv"
                                            :init="{
                                                height: 300,
                                                menubar: false,
                                                plugins: [
                                                'advlist autolink lists link image charmap print preview anchor',
                                                'searchreplace visualblocks code fullscreen',
                                                'insertdatetime media table paste code help wordcount'
                                                ],
                                                toolbar:
                                                'undo redo | formatselect | bold italic backcolor | \
                                                alignleft aligncenter alignright alignjustify | \
                                                bullist numlist outdent indent | removeformat | help'
                                            }"
                                        />
                                    </div>
                                    <div class="mb-3">
                                        <label for="message-text" class="col-form-label">Initial Remarks:</label>
                                        <editor
                                            api-key="h2ejcrnvgywfvz72uusmfg5zj08tsl47gegqhqyf8j7kg681"
                                            v-model="init_remarksv"
                                            id="init_remarksv"
                                            :init="{
                                                height: 300,
                                                menubar: false,
                                                plugins: [
                                                'advlist autolink lists link image charmap print preview anchor',
                                                'searchreplace visualblocks code fullscreen',
                                                'insertdatetime media table paste code help wordcount'
                                                ],
                                                toolbar:
                                                'undo redo | formatselect | bold italic backcolor | \
                                                alignleft aligncenter alignright alignjustify | \
                                                bullist numlist outdent indent | removeformat | help'
                                            }"
                                        />
                                    </div>
                                </form>                    
                            </div>
                            <div class="col-sm">
                            <BreezeRemarks 
                                user="marlon_rafols"
                                remark="The first argument passed to the hasOne method is the name of the related model class. Once the relationship is defined, we may retrieve the related record using Eloquent's dynamic properties."
                            >
                                Recent Updates
                            </BreezeRemarks>
                            </div>
                        </div>
                    </div>                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">X</button>
                    <button type="button" class="btn btn-danger">Update Information</button>
                    <button type="button" class="btn btn-primary">Pending</button>
                    <button type="button" class="btn btn-warning">Callback</button>
                    <button type="button" class="btn btn-success">Closed</button>
                </div>
                </div>
            </div>
        </div>
    </BreezeAuthenticatedLayout>
</template>

<script>
import BreezeAuthenticatedLayout from '@/Layouts/Authenticated.vue';
import BreezeRemarks from '@/Components/Remark.vue';
import { Head } from '@inertiajs/inertia-vue3';
import Editor from '@tinymce/tinymce-vue';
import { Inertia } from '@inertiajs/inertia';
import { reactive } from 'vue';
import BreezeApplicationLogo from '@/Components/ApplicationLogo.vue';

export default {
    components: {
        BreezeAuthenticatedLayout,
        Head,
        'editor': Editor,
        BreezeRemarks,
    },
    props: {
        new_cnt: Number,
        contacted_cnt: Number,
        callback_cnt: Number,
        closed_cnt: Number,
        contacts: Array,
        contacteds: Array,
        callbacks: Array,
        closeds: Array,
    },
    data() {
        return {
            recipient: null,
            informations: null,
            init_remarks: "Newly added contact",
        }
    },    
    methods:{
        new_ontacts: function() {
            Inertia.reload('contacts');
        },
        contacted: function() {
            Inertia.reload('contacts');
        },
        callback: function() {
            Inertia.reload('contacts');
        },
        closed: function() {
            Inertia.reload('contacts');
        },
        modal_submit: function() {
            if(typeof this.recipient == 'undefined'){
                alert('The recipient should not be empty!');
            }if(typeof this.informations == 'undefined'){
                alert('The informations should not be empty!');
            }else{
                alert('You are about to submit the entry.');
                this.$inertia.visit('/contacts/new', {
                    method: 'post',
                    data: {
                        'recipient': this.recipient,
                        'informations': this.informations,
                        'init_remarks': this.init_remarks
                    },
                });
                console.log(this.recipient, this.informations, this.init_remarks);
                var $modal = $('#newContactModal');
                //when hidden
                $modal.modal('hide'); //start hiding
            }
        },
        modal_open: function() {
            $('#newContactModal').on('shown.bs.modal', function () {
                $('#recipient').trigger('focus').val("");
                tinymce.get("informations").setContent("");
                tinymce.get("init_remarks").setContent(this.init_remarks);
            });
        }
    }
}
</script>
