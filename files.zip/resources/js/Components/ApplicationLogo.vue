<template>
    <img src="images/logo.png" alt="Logo" title="Logo"/>
</template>
