<?php

use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return Inertia::render('Auth/Login', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::get('/dashboard', [App\Http\Controllers\DashboardController::class, 'dashboard'])->middleware(['auth', 'verified'])->name('dashboard');
Route::get('/contacts', [App\Http\Controllers\ContactController::class, 'contacts'])->middleware(['auth', 'verified'])->name('contacts');
Route::get('/settings', [App\Http\Controllers\SettingController::class, 'roles'])->middleware(['auth', 'verified'])->name('settings');
Route::get('/roles', [App\Http\Controllers\SettingController::class, 'roles'])->middleware(['auth', 'verified'])->name('roles');
Route::get('/marks', [App\Http\Controllers\SettingController::class, 'marks'])->middleware(['auth', 'verified'])->name('marks');

Route::post('/contacts/new', [App\Http\Controllers\ContactController::class, 'newContact'])->middleware(['auth', 'verified'])->name('contacts.new');

require __DIR__.'/auth.php';
