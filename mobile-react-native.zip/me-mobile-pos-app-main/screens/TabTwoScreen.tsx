import React, {useState, useEffect, useCallback} from 'react';
import { RefreshControl, SafeAreaView, ScrollView, StyleSheet } from 'react-native';
import { userProductionDetails } from '../api'
import * as SecureStore from 'expo-secure-store';
import {useNavigation} from '@react-navigation/native';
import {StackNavigationProp} from '@react-navigation/stack';
import { RootStackParamList } from '../types';

import SalesScreenInfo from '../components/SalesScreenInfo';
import { Text, View } from '../components/Themed';

type authScreenProp = StackNavigationProp<RootStackParamList, 'Auth'>;

export default function TabTwoScreen() {

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [data, setData] = useState<any>(null);
  const navigation = useNavigation<authScreenProp>();
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    getProductDetails();
  },[]);

  const wait = (timeout:any) => {
    return new Promise(resolve => setTimeout(resolve, timeout));
  }
  
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setIsLoading(false);
    wait(2000).then(() => setRefreshing(false));
    getProductDetails();
  }, []);

  const getProductDetails = () => {
    setData(null);
    async function fetchMyAPI() {
      setIsLoading(true);
      let token = await SecureStore.getItemAsync('_token');
      let userId = await SecureStore.getItemAsync('_userId');
      userProductionDetails(JSON.stringify(userId),JSON.stringify(token)).then((response)=>{
        setData(response.branches);
        setIsLoading(false);
      });
    }
    fetchMyAPI();
  }  

  return (
    <View style={styles.container}>
      <SafeAreaView>
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
            />
          }
        >  
        <SalesScreenInfo path="/screens/TabTwoScreen.tsx" data={data} isLoading={isLoading}/>
      </ScrollView>
    </SafeAreaView>
  </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop:200,
  },
});
