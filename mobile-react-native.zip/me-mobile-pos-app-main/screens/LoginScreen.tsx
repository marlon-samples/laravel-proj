import * as React from 'react';
import {
    StyleSheet,
    View,
  } from "react-native";
  
import LoginScreenInfo from '../components/LoginScreenInfo';

export default function LoginScreen() {
  return (
    <View style={styles.container}>
      <LoginScreenInfo path="/screens/LoginScreen.tsx" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
