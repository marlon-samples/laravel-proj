import * as React from 'react';
import { StyleSheet } from 'react-native';
import { Avatar } from 'react-native-elements';

import ProfileScreenInfo from '../components/ProfileScreenInfo';
import { Text, View } from '../components/Themed';

export default function TabThreeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>My Profile</Text>
      <Avatar
        size="large"
        rounded
        overlayContainerStyle={{backgroundColor: 'blue'}}
        icon={{name: 'meetup', color: 'red', type: 'font-awesome'}}
        onPress={() => console.log("Works!")}
        activeOpacity={0.7}
        containerStyle={{marginTop: 20}}
      />
      <View style={styles.separator} lightColor="#eee" darkColor="rgba(255,255,255,0.1)" />
      <ProfileScreenInfo path="/screens/TabthreeScreen.tsx" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  separator: {
    marginVertical: 30,
    height: 1,
    width: '80%',
  },
});
