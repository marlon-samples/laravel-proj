import React, {useState, useEffect, useCallback} from 'react';
import { Alert, RefreshControl, SafeAreaView, ScrollView, StyleSheet, BackHandler } from 'react-native';

import HomeScreenInfo from '../components/HomeScreenInfo';
import { View } from '../components/Themed';
import { userProductionDetails } from '../api'
import * as SecureStore from 'expo-secure-store';

export default function TabOneScreen() {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [data, setData] = useState<any>(null);
  const [refreshing, setRefreshing] = useState<boolean>(false);

  const backAction = () => {
    Alert.alert("Hold on!", "Are you sure you want to exit App?", [
      {
        text: "Cancel",
        onPress: () => onRefresh(),
        style: "cancel"
      },
      { text: "YES", onPress: () => BackHandler.exitApp() }
    ]);
    return true;
  };

  useEffect(() => {
    getUserInfo();
    BackHandler.addEventListener("hardwareBackPress", backAction);
    return () => BackHandler.removeEventListener("hardwareBackPress", backAction);
  },[]);

  const wait = (timeout:any) => {
    return new Promise(resolve => setTimeout(resolve, timeout));
  }
  
  const onRefresh = useCallback(() => {
    setRefreshing(true);
    wait(2000).then(() => setRefreshing(false));
    setData(null);
    async function fetchMyAPI() {
      let token = await SecureStore.getItemAsync('_token');
      let userId = await SecureStore.getItemAsync('_userId');
      userProductionDetails(JSON.stringify(userId),JSON.stringify(token)).then((response)=>{
        setData(response);
      });
    }
    fetchMyAPI();
  }, []);

  const getUserInfo = () => {
    setIsLoading(true);
    setData(null);
    async function fetchMyAPI() {
      let token = await SecureStore.getItemAsync('_token');
      let userId = await SecureStore.getItemAsync('_userId');
      userProductionDetails(JSON.stringify(userId),JSON.stringify(token)).then((response)=>{
        setIsLoading(false);
        setData(response);
      });
    }
    fetchMyAPI();
  }

  return (
      <View style={styles.container}>
        <SafeAreaView style={{marginTop:50, alignContent:'center',alignItems: 'center',}}>
          <ScrollView
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={onRefresh}
              />
            }
          >
          <HomeScreenInfo path="/screens/TabOneScreen.tsx" data={data} imLoading={isLoading}/> 
          </ScrollView>
        </SafeAreaView>
      </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollView: {
    flex: 1,
    backgroundColor: 'pink',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
