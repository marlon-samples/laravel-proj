import { StackScreenProps } from '@react-navigation/stack';
import * as React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { RootStackParamList } from '../types';
import ReportsScreenInfo from '../components/ReportsScreenInfo';

export default function ReportScreen({
  navigation,
}: StackScreenProps<RootStackParamList, 'Report'>) {
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.link}>
        <Text style={styles.linkText}>GO BACK TO HOME SCREEN</Text>
      </TouchableOpacity>
      <ReportsScreenInfo />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    marginTop:50,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  link: {
    marginTop: 15,
    paddingVertical: 15,
    alignItems: 'center',
  },
  linkText: {
    fontSize: 14,
    color: '#2e78b7',
  },
});
