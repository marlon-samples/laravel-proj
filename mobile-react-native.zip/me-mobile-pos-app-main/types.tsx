/**
 * Learn more about using TypeScript with React Navigation:
 * https://reactnavigation.org/docs/typescript/
 */

export type RootStackParamList = {
  Root: { data: Array<any> };
  Auth: undefined;
  Report: undefined;
  NotFound: undefined;
};

export type BottomTabParamList = {
  Home: undefined;
  Sales: undefined;
  Profile: undefined;
};

export type ModalParamList = {
  ReportDetails: undefined;
};

export type TabOneParamList = {
  TabOneScreen: undefined;
};

export type TabTwoParamList = {
  TabTwoScreen: undefined;
};

export type TabThreeParamList = {
  TabThreeScreen: undefined;
};

/** Initial Types Params */
export type LoaderProps = {
  title: string;
}

export type LoginProps = {
  isLoading: boolean;
  isLogin: string;
  email: string;
  password: string;
  _token: any;
}