import Config from "../constants/Config"; 
import * as Device from 'expo-device';
import * as SecureStore from 'expo-secure-store';
import NetInfo from "@react-native-community/netinfo";
import React, { useState } from "react";

async function save(key:any, value:any) {
  await SecureStore.setItemAsync(key, value);
}

export const loginFromApi = async (email:string, password:string) => {
  //console.log(email);
  try {
    let uri = Config.api.local+"/api/sanctum/token/";
    console.log(uri);
    let response = await fetch(uri,{
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: email,
        password: password,
        device_name: Device.brand
      })
    });
    let jwt = await response.json();
    console.log(JSON.stringify(jwt));

    (jwt.token) ? save('_token', jwt.token) : "";
    
    return jwt;
  }catch(error){
    console.error(error);
  }
}

export const userDetails = async (token:string) => {
  try {
    let uri = Config.api.local+"/api/user/";
    var _theToken = Config.sanctum.var + JSON.parse(token);
    let response = await fetch(uri,{
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': "Bearer " + _theToken,
      },
    });
    let results = await response.json();
    //console.log(JSON.stringify(results));
    return results;
  }catch(error){
    console.error(error);
  }

}

/** Live  */

export const loginFromProductionApi = async (email:string, password:string) => {
  //console.log(email);
  try {
    let uri = Config.api.production+"/api/login/";
    
    console.log(uri);

    var details:any = {
      'username': email,
      'password': password,
    };
  
    var formBody:any = [];

    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }

    formBody = formBody.join("&");  

    let response = await fetch(uri,{
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'Client-Service': 'frontend-client',
        'Auth-Key': 'menterpriseapi'
      },
      body: formBody
    });
    let jwt = await response.json();
    //console.log(JSON.stringify(jwt));
    if(jwt.token){
      save('_token', jwt.token);
      save('_userId', jwt.user_info[0].user_id); 
      save('_userBranch', jwt.user_info[0].branch_id); 
    }else{
      jwt = [];
    }
    return jwt;
  }catch(error){
    console.error(error);
  }
}

export const userProductionDetails = async (userid:string ,token:string) => {
  try {
    let uri = Config.api.production+"/api/user-info/";
    
    var details:any = {
      'User-ID': userid,
      'Authorization': token,
    };

    var formBody:any = [];
    
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }

    formBody = formBody.join("&");  

    let response = await fetch(uri,{
      method: 'POST',
      headers: {
        'Client-Service': 'frontend-client',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Auth-Key': 'menterpriseapi',
        'User-ID': JSON.parse(userid),
        //'User-ID': '1',
        'Authorization': JSON.parse(token)
        //'Authorization': '18d14105b46284b0338ef87fda48d984edff08476293b078b7a03cc3e0c6afb3'
      }
    });
    let results = await response.json();
    console.log(JSON.stringify(results));
    return results;
  }catch(error){
    console.error(error);
  }

}

export const getBranchSalesDetails = async (userid:string ,token:string, branch:string, dateFrom:string, dateTo:string) => {
  try {
    let uri = Config.api.production+"/api/sales/";
    let today = new Date();
    let formattedDate = today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
    let from:any, to:any = '';

    //console.log("From",dateFrom);
    //console.log("To",dateTo);

    from = JSON.parse(dateFrom);
    to = JSON.parse(dateTo);

    var details:any = {
      date_from: from,
      date_to: to,
      branch_id: JSON.parse(branch),
      search_key: '',
      limit: '',
      offset: '',
    };

    //console.log("Formated",formattedDate);

    var formBody:any = [];
    
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }

    formBody = formBody.join("&");  

    let response = await fetch(uri,{
      method: 'POST',
      headers: {
        'Client-Service': 'frontend-client',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Auth-Key': 'menterpriseapi',
        'User-ID': JSON.parse(userid),
        'Authorization': JSON.parse(token)
      },
      body: formBody
    });
    let results = await response.json();
    //console.log(JSON.stringify(results));
    return results;
  }catch(error){
    console.error(error);
  }

}

export const checkToken = async (userid:string ,token:string) => {
  try {
    let uri = Config.api.production+"/api/checker/";
    
    var details:any = {
      'User-ID': userid,
      'Authorization': token,
    };

    var formBody:any = [];
    
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }

    formBody = formBody.join("&");  

    let response = await fetch(uri,{
      method: 'POST',
      headers: {
        'Client-Service': 'frontend-client',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Auth-Key': 'menterpriseapi',
        'User-ID': JSON.parse(userid),
        'Authorization': JSON.parse(token)
      }
    });
    let results = await response.json();
    console.log(JSON.stringify(results));
    return results;
  }catch(error){
    console.error(error);
  }

}

export const logOutFromApi = async (userid:string ,token:string) => {
  try {
    let uri = Config.api.production+"/api/logout/";
    
    var details:any = {
      'User-ID': userid,
      'Authorization': token,
    };

    var formBody:any = [];
    
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }

    formBody = formBody.join("&");  

    let response = await fetch(uri,{
      method: 'POST',
      headers: {
        'Client-Service': 'frontend-client',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Auth-Key': 'menterpriseapi',
        'User-ID': JSON.parse(userid),
        'Authorization': JSON.parse(token)
      }
    });
    let results = await response.json();
    console.log(JSON.stringify(results));
    return results;
  }catch(error){
    console.error(error);
  }

}
