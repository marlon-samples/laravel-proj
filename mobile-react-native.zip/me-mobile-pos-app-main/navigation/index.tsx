/**
 * If you are not familiar with React Navigation, check out the "Fundamentals" guide:
 * https://reactnavigation.org/docs/getting-started
 *
 */
import { NavigationContainer, useNavigation, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createStackNavigator, StackNavigationProp } from '@react-navigation/stack';

import * as React from 'react';
import { useState } from "react";

import {
  ColorSchemeName,
  StyleSheet,
} from "react-native";

import NotFoundScreen from '../screens/NotFoundScreen';
import ReportScreen from '../screens/ReportScreen';
import LoginScreen from '../screens/LoginScreen';
import { RootStackParamList, LoginProps } from '../types';
import BottomTabNavigator from './BottomTabNavigator';
import ModalStackNavigator from './ModalStackNavigator';
import LinkingConfiguration from './LinkingConfiguration';
import Colors from '../constants/Colors';
import { renderNode } from 'react-native-elements/dist/helpers';

export default function Navigation({ colorScheme }: { colorScheme: ColorSchemeName }) {
  return (
    <NavigationContainer
      linking={LinkingConfiguration}
      theme={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
      <RootNavigator />
    </NavigationContainer>
  );

}

// A root stack navigator is often used for displaying modals on top of all other content
// Read more here: https://reactnavigation.org/docs/modal
const Stack = createStackNavigator<RootStackParamList>();

function RootNavigator() {

  const [isLoading, setIsLoading] = useState(false);
  const [isLogin, setIsLogin] = useState(false);

  return (
    <Stack.Navigator initialRouteName="Auth" screenOptions={{ headerShown: false, headerStyle: {backgroundColor: Colors.light.headerStyleColor} }}>
      <Stack.Screen name="Auth" 
        options={({ route, navigation }) => ({
          title: route.name,
          headerTintColor: Colors.dark.text,
        })}        
        component={LoginScreen}/>
      <Stack.Screen name="Root"
        options={({ route, navigation }) => ({
          title: route.name,
          headerTintColor: Colors.dark.text,
        })}        
        component={BottomTabNavigator}
      />
      <Stack.Screen name="Report" 
        component={ModalStackNavigator} 
        options={({ route, navigation }) => ({
          title: route.name,
          headerTintColor: Colors.dark.text,
        })}        
      />
      <Stack.Screen name="NotFound" 
        component={NotFoundScreen} 
        options={({ route, navigation }) => ({
          title: route.name,
          headerTintColor: Colors.dark.text,
        })}        
      />
    </Stack.Navigator>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
 
  image: {
    marginBottom: 40,
    width: 200,
    height: 200,
  },
 
  inputView: {
    backgroundColor: "#FFC0CB",
    borderRadius: 30,
    width: "70%",
    height: 45,
    marginBottom: 20,
 
    alignItems: "center",
  },
 
  TextInput: {
    height: 50,
    flex: 1,
  },
 
  forgot_button: {
    height: 30,
    marginBottom: 30,
  },
 
  loginBtn: {
    width: "80%",
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    backgroundColor: "#FF1493",
  },

  loginText: {
    color: "#fff",
  },

  horizontal: {
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 10
  },
  
});
