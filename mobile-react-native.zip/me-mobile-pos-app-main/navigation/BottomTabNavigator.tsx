/**
 * Learn more about createBottomTabNavigator:
 * https://reactnavigation.org/docs/bottom-tab-navigator
 */

import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import React, {useState, useEffect} from 'react';
import { Alert, Button, Text, TouchableOpacity, View} from 'react-native';

import Colors from '../constants/Colors';
import useColorScheme from '../hooks/useColorScheme';
import TabOneScreen from '../screens/TabOneScreen';
import TabTwoScreen from '../screens/TabTwoScreen';
import TabThreeScreen from '../screens/TabThreeScreen';
import { BottomTabParamList, TabOneParamList, TabTwoParamList, TabThreeParamList } from '../types';
import LoadingIndicator from '../components/LoadingIndicator';
import * as SecureStore from 'expo-secure-store';
import { getBranchSalesDetails } from '../api';

import HomeScreenInfo from '../components/HomeScreenInfo';
import { NavigationContainer } from '@react-navigation/native';

const BottomTab = createBottomTabNavigator<BottomTabParamList>();

export default function BottomTabNavigator() {
  let today = new Date();
  let formattedDate = JSON.stringify(today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate());

  const colorScheme = useColorScheme();
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [badgeCount, setBadgeCount] = useState<any>(0);
  const [dateSelectFrom, setDateSelectFrom] = useState<any>(formattedDate);
  const [dateSelectTo, setDateSelectTo] = useState<any>(formattedDate);

  useEffect(() => {
    setIsLoading(true);
    async function fetchMyAPI() {
      setIsLoading(true);
      let token = await SecureStore.getItemAsync('_token');
      let userId = await SecureStore.getItemAsync('_userId');
      let branchId = await SecureStore.getItemAsync('_userBranch');

      getBranchSalesDetails(
        JSON.stringify(userId),
        JSON.stringify(token),
        JSON.stringify(branchId),
        dateSelectFrom,
        dateSelectTo           
      )
      .then((response)=>{
        const result = response.reduce((total:any, currentValue:any) => total = total + 1,0);
        setBadgeCount(result);
        setIsLoading(false);
      });
    }
    fetchMyAPI();
  },[]);
  
  return (
    <BottomTab.Navigator
      initialRouteName="Home"
      tabBarOptions={{
        activeTintColor: Colors[colorScheme].tint, 
        inactiveTintColor: Colors[colorScheme].tabIconDefault, 
        activeBackgroundColor: Colors.light.headerStyleColor,
      }}>
      <BottomTab.Screen
        name="Home"
        component={TabOneNavigator}
        options={({ route, navigation }) => ({
          tabBarLabel: route.name,
          tabBarIcon: ({ color }) => <TabBarIcon name="home" color={color} />,
        })}        
      />
      <BottomTab.Screen
        name="Sales"
        component={TabTwoNavigator}
        options={({ route, navigation }) => ({
          tabBarBadge: badgeCount,
          tabBarLabel: route.name,
          tabBarIcon: ({ color }) => <TabBarIcon name="logo-usd" color={color} />,
        })}        
      />
      <BottomTab.Screen
        name="Profile"
        component={TabThreeNavigator}
        options={({ route, navigation }) => ({
          tabBarLabel: route.name,
          tabBarIcon: ({ color }) => <TabBarIcon name="person" color={color} />,
        })}        
      />
    </BottomTab.Navigator>
  );
}

// You can explore the built-in icon families and icons on the web at:
// https://icons.expo.fyi/
function TabBarIcon(props: { name: React.ComponentProps<typeof Ionicons>['name']; color: string }) {
  return <Ionicons size={30} style={{ marginBottom: -3 }} {...props} />;
}

// Each tab has its own navigation stack, you can read more about this pattern here:
// https://reactnavigation.org/docs/tab-based-navigation#a-stack-navigator-for-each-tab
const TabOneStack = createStackNavigator<TabOneParamList>();

function TabOneNavigator() {
  return (
    <TabOneStack.Navigator>
      <TabOneStack.Screen
        name="TabOneScreen"
        component={TabOneScreen}
        options={({ route, navigation }) => ({
          headerTitle: 'HOME', 
          headerStyle: {backgroundColor: Colors.light.headerStyleColor}, 
          headerTintColor: Colors.dark.text,
          headerTitleAlign: 'center',
          headerLeft:() => (
            <TouchableOpacity style={{marginLeft:5}} onPress={() => null }>
              <TabBarIcon name="arrow-back" color="#fff"/>
            </TouchableOpacity>
          ),
        })}        
      />
    </TabOneStack.Navigator>
  );
}

const TabTwoStack = createStackNavigator<TabTwoParamList>();

function TabTwoNavigator() {
  return (
    <TabTwoStack.Navigator>
      <TabTwoStack.Screen
        name="TabTwoScreen"
        component={TabTwoScreen}
        options={({ route, navigation }) => ({
          headerTitle: 'SALES', 
          headerStyle: {backgroundColor: Colors.light.headerStyleColor}, 
          headerTintColor: Colors.dark.text,
          headerTitleAlign: 'center',
          headerLeft:() => (
            <TouchableOpacity style={{marginLeft:5}} onPress={() => navigation.goBack() }>
              <TabBarIcon name="arrow-back" color="#fff"/>
            </TouchableOpacity>
          ),
        })}        
      />
    </TabTwoStack.Navigator>
  );
}

const TabThreeStack = createStackNavigator<TabThreeParamList>();

function TabThreeNavigator() {
  return (
    <TabThreeStack.Navigator>
      <TabThreeStack.Screen
        name="TabThreeScreen"
        component={TabThreeScreen}
        options={({ route, navigation }) => ({
          headerTitle: 'PROFILE', 
          headerStyle: {backgroundColor: Colors.light.headerStyleColor}, 
          headerTintColor: Colors.dark.text,
          headerTitleAlign: 'center',
          headerLeft:() => (
            <TouchableOpacity style={{marginLeft:5}} onPress={() => navigation.goBack() }>
              <TabBarIcon name="arrow-back" color="#fff"/>
            </TouchableOpacity>
          ),
        })}        
      />
    </TabThreeStack.Navigator>
  );
}
