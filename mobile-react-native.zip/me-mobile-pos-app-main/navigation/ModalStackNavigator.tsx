import * as React from 'react';
import { View, Text, Button } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import ReportScreen from '../screens/ReportScreen';
import {ModalParamList} from '../types';

const ModalStack = createStackNavigator<ModalParamList>();

function ModalNavigationApp() {
    return (
        <ModalStack.Navigator mode="modal" headerMode="none">
            <ModalStack.Screen name="ReportDetails" component={ReportScreen} />
        </ModalStack.Navigator>
    );
  }

  export default ModalNavigationApp;