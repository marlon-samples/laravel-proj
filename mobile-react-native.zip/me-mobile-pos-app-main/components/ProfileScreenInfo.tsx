import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Alert,
} from "react-native";

import Config from '../constants/Config';
import { userDetails, userProductionDetails, logOutFromApi } from '../api'
import * as SecureStore from 'expo-secure-store';
import LoadingIndicator from '../components/LoadingIndicator';
import {useNavigation} from '@react-navigation/native';
import {StackNavigationProp} from '@react-navigation/stack';
import { RootStackParamList } from '../types';

type authScreenProp = StackNavigationProp<RootStackParamList, 'Auth'>;

async function save(key:any, value:any) {
  await SecureStore.setItemAsync(key, value);
}

export default function ProfileScreenInfo({ path }: { path: string }) {

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [data, setData] = useState<any>(null);
  
  const navigation = useNavigation<authScreenProp>();

  useEffect(() => {
    setData(null);
    async function fetchMyAPI() {
      setIsLoading(true);
      let token = await SecureStore.getItemAsync('_token');
      let userId = await SecureStore.getItemAsync('_userId');
      userProductionDetails(JSON.stringify(userId),JSON.stringify(token)).then((response)=>{
        setData(response);
        setIsLoading(false);
      });
    }
    fetchMyAPI();
  },[]);

const logOut = async () => {
  let token = await SecureStore.getItemAsync('_token');
  let userId = await SecureStore.getItemAsync('_userId');
  logOutFromApi(JSON.stringify(token), JSON.stringify(userId)).then((response)=>{
    console.log('Message: ', response.message);
    save('_token', "");
    save('_userId', "");
    navigation.navigate('Auth'); 
  });
}

const logMeOutToApp = () => {
  Alert.alert(
      "Logout",
      "Continue Logout?",
      [
        { text: "Yes", onPress: () => logOut() },
        { text: "No", onPress: () => console.log("Cancel Pressed") , style: 'cancel' },
      ],
      { 
        cancelable: true 
      }
  );
}

return (      
    <View style={styles.getStartedContainer}>
        {isLoading ? <LoadingIndicator title="Loading..." /> : null }
        <Text>Name: {(data) ? data.user_info[0].fullname : ""}</Text>        
        <Text>Email: email@domain.com</Text>        
        <Text>Company: {(data) ? data.user_info[0].company_name : ""}</Text>        
        <Text>Branch: {(data) ? data.user_info[0].branch_name : ""}</Text>        
        <Text>App Version: {Config.api.version}</Text>
        <Text>API Version: 1.0.0</Text>
        <TouchableOpacity style={styles.loginBtn}>
          <Text style={styles.loginText} onPress={logMeOutToApp}>Logout</Text>
        </TouchableOpacity>      
    </View>
  );
}

const styles = StyleSheet.create({
  getStartedContainer: {
    alignItems: 'center',
    marginHorizontal: 50,
    marginTop: 15,
  },
  homeScreenFilename: {
    marginVertical: 7,
  },
  codeHighlightContainer: {
    borderRadius: 3,
    paddingHorizontal: 4,
  },
  getStartedText: {
    fontSize: 17,
    lineHeight: 24,
    textAlign: 'center',
  },
  loginBtn: {
    width: 200,
    borderRadius: 25,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 40,
    backgroundColor: "#FF1493",
  },
  loginText: {
    color: "#fff",
  },  
});
