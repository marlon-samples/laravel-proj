import React, {useState, useEffect, useCallback} from 'react';
import {
  RefreshControl, 
  SafeAreaView, 
  ScrollView,
  StyleSheet,
} from "react-native";
import Colors from '../constants/Colors';
import { MonoText } from './StyledText';
import { View } from './Themed';
import AppSelector from './SelectorScreenInfo';

export default function SalesScreenInfo({ path, data, isLoading }: { path: string, data:any, isLoading:boolean }) {

return (      
    <View style={styles.getStartedContainer}>
        <AppSelector data={data} isLoading={isLoading}/>
    </View>
  );
}

const styles = StyleSheet.create({
  getStartedContainer: {
    alignItems: 'center',
    marginHorizontal: 50,
    marginTop: 15,
  },
  homeScreenFilename: {
    marginVertical: 7,
  },
  codeHighlightContainer: {
    borderRadius: 3,
    paddingHorizontal: 4,
  },
  getStartedText: {
    fontSize: 17,
    lineHeight: 24,
    textAlign: 'center',
  },
});
