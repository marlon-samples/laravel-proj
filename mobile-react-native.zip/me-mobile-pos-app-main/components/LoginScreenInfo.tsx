import * as WebBrowser from 'expo-web-browser';
import React, {useState, useEffect} from 'react';
import { StatusBar } from "expo-status-bar";
import {
    StyleSheet,
    Text,
    View,
    Image,
    TextInput,
    TouchableOpacity,
    Alert,
  } from "react-native";

import {useNavigation} from '@react-navigation/native';
import {StackNavigationProp} from '@react-navigation/stack';
import { RootStackParamList } from '../types';
import { LoginProps } from '../types';
import LoadingIndicator from '../components/LoadingIndicator';
import { loginFromApi, loginFromProductionApi, checkToken } from '../api';
import * as SecureStore from 'expo-secure-store';
import NetInfo from "@react-native-community/netinfo";

type authScreenProp = StackNavigationProp<RootStackParamList, 'Auth'>;

export default function LoginScreenInfo( { path }: { path: string }) {

    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [email, setEmail] = useState<string>("");
    const [password, setPassword] = useState<string>("");
    const [data, setData] = useState<any>([]);
    const [connectionType, setConnectionType] = useState<any>('none');
    const [imConnected, setImConnected] = useState<any>(false);
  
    const navigation = useNavigation<authScreenProp>();

    useEffect(() => {
      setIsLoading(false);
      const checkLogin = async () => {
        let result = await SecureStore.getItemAsync('_token');
        let userId = await SecureStore.getItemAsync('_userId');

        NetInfo.fetch().then(state => {
          if(state.isConnected) {
            setConnectionType(state.type);
            setImConnected(state.isConnected);
            setIsLoading(true);
            checkToken(JSON.stringify(userId), JSON.stringify(result)).then((response) =>{
              setIsLoading(true);
              if(response.flag){
                console.log('Access Granted...', result);
                navigation.navigate('Root', {data: data});
              }else{
                setIsLoading(false);
                console.log('Need Authentication...', result);
                navigation.navigate('Auth'); 
              }
            });
            console.log("Connection type", connectionType);
            console.log("Is connected?", imConnected);
          }else{
              setConnectionType('none');
              setImConnected(false);
              console.log("Connection type", connectionType);
              console.log("Is connected?", imConnected);
          }
        });
      }
      checkLogin();
    },[]);

    const pressYes = async () => {
      setIsLoading(false);
      (email !="" && password !="" ) ?  
      loginFromProductionApi(email, password).then((response)=>{            
          setIsLoading(false);
          if(response.token) {
              setIsLoading(true);
              setData(response);
              console.log('Login Success...');
              navigation.navigate('Root', {data: data}); 
            }else{
              setIsLoading(false);
              Alert.alert(
                  "Authentication",
                  "Opps! " + "Invalid Credentials, Please contact your Administrator!"
              );
            }
        })
      : Alert.alert(
        "Email & Password Required",
        "Please provide the email and password!"
      );
    }

    const pressNo = () => {
        setIsLoading(false);
        console.log("No Pressed");
    }

    const logMeToApp = () => {
        Alert.alert(
            "Login",
            "Continue Login?",
            [
              { text: "Yes", onPress: () => pressYes() },
              { text: "No", onPress: () => pressNo() , style: 'cancel' },
            ],
            { 
              cancelable: true 
            }
        );
    }

    return (      
        <View style={styles.container}>
            <Image style={styles.image} source={require('../assets/images/adaptive-icon.png')} />
            <StatusBar style="auto" />
            {!imConnected ? <LoadingIndicator title={ (isLoading) ? "Logging In..." : "Connecting..."} /> : null }
            <View style={styles.inputView}>
                <TextInput
                    style={styles.TextInput}
                    placeholder="Username"
                    placeholderTextColor="#003f5c"
                    onChangeText={(email) => setEmail(email)}
                />
            </View>
            <View style={styles.inputView}>
                <TextInput
                style={styles.TextInput}
                placeholder="Password"
                placeholderTextColor="#003f5c"
                secureTextEntry={true}
                onChangeText={(password) => setPassword(password)}
                />
            </View>
            <TouchableOpacity>
                <Text style={styles.forgot_button} >Forgot Password?</Text>
            </TouchableOpacity>
    
            <TouchableOpacity style={styles.loginBtn} onPress={logMeToApp}>
                <Text style={styles.loginText} onPress={logMeToApp}>LOGIN</Text>
            </TouchableOpacity>

        </View>
    );

}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#fff",
      alignItems: "center",
      justifyContent: "center",
    },
   
    image: {
      marginBottom: 40,
      width: 200,
      height: 200,
    },
   
    inputView: {
      backgroundColor: "#FFC0CB",
      borderRadius: 30,
      width: "70%",
      height: 45,
      marginBottom: 20,
   
      alignItems: "center",
    },
   
    TextInput: {
      height: 50,
      flex: 1,
    },
   
    forgot_button: {
      height: 30,
      marginBottom: 30,
    },
   
    loginBtn: {
      width: "80%",
      borderRadius: 25,
      height: 50,
      alignItems: "center",
      justifyContent: "center",
      marginTop: 40,
      backgroundColor: "#FF1493",
    },
  
    loginText: {
      color: "#fff",
    },
  
    horizontal: {
      flexDirection: "row",
      justifyContent: "space-around",
      padding: 10
    },
    
  });
