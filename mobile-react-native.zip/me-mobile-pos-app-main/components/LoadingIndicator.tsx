import * as React from 'react';
import { FunctionComponent } from "react";
import { LoaderProps } from '../types';
import {
    StyleSheet,
    Text,
    View,
    ActivityIndicator,
  } from "react-native";

const LoadingIndicator: FunctionComponent<LoaderProps> = ({title}) => (
    <View style={styles.container} >
        <ActivityIndicator 
            size="large" 
            color="#ffc6e0"
        />
        <Text style={{color: '#fff', margin:10}}>{title}</Text>
    </View>
);
const styles = StyleSheet.create({
    container: {
        backgroundColor: "#e33f89",
        alignItems: "center",
        justifyContent: "center",
        width: 100,
        height: 100,
        borderRadius: 10,
        position: 'absolute',
        zIndex: 99999,
      },    
});
export default LoadingIndicator;