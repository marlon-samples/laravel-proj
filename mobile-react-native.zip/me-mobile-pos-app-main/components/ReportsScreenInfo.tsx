import React, {useState, useEffect} from 'react';
import { StyleSheet, Text, TouchableOpacity, View, Platform, Button, SafeAreaView, ScrollView } from 'react-native';
import { Table, Row, Rows } from 'react-native-table-component';
import LoadingIndicator from '../components/LoadingIndicator';
import * as SecureStore from 'expo-secure-store';
import { getBranchSalesDetails } from '../api';
import {useNavigation} from '@react-navigation/native';
import {StackNavigationProp} from '@react-navigation/stack';
import { RootStackParamList } from '../types';
import DateTimePicker from '@react-native-community/datetimepicker';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Input } from 'react-native-elements';
import { Alert } from 'react-native';
import Colors from '../constants/Colors';

type authScreenProp = StackNavigationProp<RootStackParamList, 'Auth'>;

export default function ReportsScreenInfo()  {
      let today = new Date();
      let formattedDate = JSON.stringify(today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate());

      const [isLoading, setIsLoading] = useState<boolean>(false);
      const [data, setData] = useState<any>([]);
      const [date, setDate] = useState<any>(new Date());
      const [mode, setMode] = useState<any>('date');
      const [show, setShow] = useState<any>(false);
      const [dateAction, setDateAction] = useState<string>('');
      const [dateSelectFrom, setDateSelectFrom] = useState<any>(formattedDate);
      const [dateSelectTo, setDateSelectTo] = useState<any>(formattedDate);
      const [total, setTotal] = useState<any>(0);

      const navigation = useNavigation<authScreenProp>();

      useEffect(() => {
        setData(null);
        async function fetchMyAPI() {
          setIsLoading(true);
          let token = await SecureStore.getItemAsync('_token');
          let userId = await SecureStore.getItemAsync('_userId');
          let branchId = await SecureStore.getItemAsync('_userBranch');

          getBranchSalesDetails(
            JSON.stringify(userId),
            JSON.stringify(token),
            JSON.stringify(branchId),
            dateSelectFrom,
            dateSelectTo           
          )
          .then((response)=>{
            const tableData = response.map( (record:any) =>([record.posp_datecreated, record.pos_order_num, record.posp_amount_due]));
            const result = response.reduce((total:any, currentValue:any) => total = total + JSON.parse(currentValue.posp_amount_due),0);
            setTotal(currencyFormat(result));
            setData(tableData);
            setIsLoading(false);
          });
        }
        fetchMyAPI();
      },[]);

      const pressYes = () => {
        setData(null);
        async function fetchMyAPI() {
          setIsLoading(true);
          let token = await SecureStore.getItemAsync('_token');
          let userId = await SecureStore.getItemAsync('_userId');
          let branchId = await SecureStore.getItemAsync('_userBranch');

          getBranchSalesDetails(
            JSON.stringify(userId),
            JSON.stringify(token),
            JSON.stringify(branchId),
            dateSelectFrom,
            dateSelectTo           
          )
          .then((response)=>{
            const tableData = response.map( (record:any) =>([record.datecreated, record.pos_order_num, record.posp_amount_due]));
            const result = response.reduce((total:any, currentValue:any) => total = total + JSON.parse(currentValue.posp_amount_due),0);
            setTotal(currencyFormat(result));
            setData(tableData);
            setIsLoading(false);
          });
        }
        fetchMyAPI();
      }
      
      function currencyFormat(num:any) {
        return num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
      }

      const onChange = (event:any, selectedDate:any) => {
        const currentDate:any = selectedDate || date;
        setShow(Platform.OS === 'ios');
        setDate(currentDate);
        let formattedDate = selectedDate.getFullYear() + "-" + (selectedDate.getMonth() + 1) + "-" + selectedDate.getDate();
        (dateAction === "from") ? setDateSelectFrom(JSON.stringify(formattedDate)) : setDateSelectTo(JSON.stringify(formattedDate));
        //console.log('the date --> ',selectedDate)
      };
    
      const showMode = (currentMode:any) => {
        setShow(true);
        setMode(currentMode);
      };
    
      const showDatepickerFrom = () => {
        setDateAction('from')
        showMode('date');
      };

      const showDatepickerTo = () => {
        setDateAction('to')
        showMode('date');
      };

      const showResults = () => {
        Alert.alert(
          "Generate",
          "Do you want continue?",
          [
            { text: "Yes", onPress: () => pressYes() },
            { text: "No", onPress: () => console.log('Press No') , style: 'cancel' },
          ],
          { 
            cancelable: true 
          }
        );
      }

      const tableHead:Array<any> = ['Date', 'Order#', 'Amount'];
      const [thead, setThead] = React.useState<any>(tableHead);

      //console.log("Data-->", data);

      return (
        <View style={styles.container}>
          <View style={{alignContent:'center',alignItems: 'center',}}>
            {isLoading ? <LoadingIndicator title="Loading..." /> : null }
          </View>
          <SafeAreaView>
            <ScrollView>
              <View style={{paddingBottom: 10,}}>
              <Text>Date From: (Press calendar Icon to select date)</Text>
                <Input
                  placeholder='yyyy-mm-dd'
                  leftIcon={
                    <Icon
                      name='calendar'
                      size={18}
                      color={Colors.light.headerStyleColor}
                      onPress={showDatepickerFrom}
                    />
                  }
                  value={(dateSelectFrom) ? JSON.parse(dateSelectFrom) : dateSelectFrom}
                />
                <Text>Date To: (Press calendar Icon to select date)</Text>
                <Input
                  placeholder='yyyy-mm-dd'
                  leftIcon={
                    <Icon
                      name='calendar'
                      size={18}
                      color={Colors.light.headerStyleColor}
                      onPress={showDatepickerTo}
                    />
                  }
                  value={(dateSelectTo) ? JSON.parse(dateSelectTo) : dateSelectTo}
                />
                <View>
                  <Button color={Colors.light.headerStyleColor} onPress={showResults} title="Submit" />
                </View>
              </View>
              {show && (
                <DateTimePicker
                  testID="dateTimePicker"
                  value={date}
                  mode={mode}
                  is24Hour={true}
                  display="default"
                  onChange={onChange}
                />
              )}
              <Table borderStyle={{borderWidth: 2, borderColor: '#c8e1ff'}}>
                <Row data={thead} style={styles.head} textStyle={styles.text}/>
                <Rows data={data} textStyle={styles.text}/>
              </Table>
              <Text style={{fontSize: 16, marginTop:10}}>Total: {total}</Text>
            </ScrollView>
          </SafeAreaView>    
        </View>
      )
  }
  
  const styles = StyleSheet.create({
    container: { padding: 16, paddingTop: 30, backgroundColor: '#fff', width:350, },
    head: { height: 40, backgroundColor: '#f1f8ff' },
    text: { margin: 6 }
  });