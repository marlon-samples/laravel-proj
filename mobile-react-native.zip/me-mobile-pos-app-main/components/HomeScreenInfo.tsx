import * as WebBrowser from 'expo-web-browser';
import React, {useState, useEffect} from 'react';
import { StyleSheet, TouchableOpacity, Image } from 'react-native';
import LoadingIndicator from '../components/LoadingIndicator';

import { Text, View } from './Themed';
import Config from '../constants/Config';

export default function HomeScreenInfo({ path, data, imLoading }: { path: string, data: any, imLoading: boolean }) {

  return (
    <View>
      <View style={{marginTop:50, alignContent:'center',alignItems: 'center',}}>
        {imLoading ? <LoadingIndicator title="Loading..." /> : null }
        <Text style={styles.title}>Welcome to {(data) ? data.user_info[0].company_name : ""}</Text>
        <Text style={styles.title}>Sales Monitoring App</Text>
        <View style={styles.separator} lightColor="#eee" darkColor="rgba(255,255,255,0.1)" />
      </View>
      <View style={styles.getStartedContainer}>
        <Image 
          style={styles.largeLogo}
          source={require('../assets/images/adaptive-icon.png')} 
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  getStartedContainer: {
    alignItems: 'center',
    marginHorizontal: 50,
  },
  homeScreenFilename: {
    marginVertical: 7,
  },
  codeHighlightContainer: {
    borderRadius: 3,
    paddingHorizontal: 4,
  },
  getStartedText: {
    fontSize: 17,
    lineHeight: 24,
    textAlign: 'center',
  },
  helpContainer: {
    marginTop: 15,
    marginHorizontal: 20,
    alignItems: 'center',
  },
  helpLink: {
    paddingVertical: 15,
  },
  helpLinkText: {
    textAlign: 'center',
  },
  largeLogo: {
    width: 200,
    height: 200,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  separator: {
    marginVertical: 30,
    height: 1,
    width: '80%',
  },
});
 