import React, {useState, useEffect, useCallback} from 'react';
import {
  Alert,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Button, Divider } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';
import LoadingIndicator from '../components/LoadingIndicator';
import {useNavigation} from '@react-navigation/native';
import {StackNavigationProp} from '@react-navigation/stack';
import { RootStackParamList } from '../types';

type authScreenProp = StackNavigationProp<RootStackParamList, 'Auth'>;

function AppSelector({data, isLoading} : {data:any, isLoading:boolean}) {
  const navigation = useNavigation<authScreenProp>();
  
  const getBranch = async () => {
    Alert.alert(
      "View Branch",
      "You want to view sales?",
      [
        { text: "Cancel", onPress: () => console.log("Cancel") , style: 'cancel' },
        { text: "Yes", onPress: () => navigation.navigate('Report') },
      ],
      { 
        cancelable: true 
      }
    );
  }

  return (
    <View style={styles.container}>
      <View style={{alignContent:'center',alignItems: 'center',zIndex:999,}}>
        {isLoading ? <LoadingIndicator title="Loading..." /> : null }
      </View>
        <Text style={styles.title}>SELECT BRANCH</Text>
        <View style={styles.separator} />

        {(data) ?
          data.map((branch:any) => {
            return(
              <View key={branch.br_id} style={{ width: '100%', alignItems: 'center'}}>
                <Button
                  icon={
                    <Icon
                      name="arrow-right"
                      size={15}
                      color="white"
                      style={styles.icon}
                    />
                  }
                  title={branch.br_name}
                  buttonStyle={styles.loginBtn}
                  onPress={getBranch}
                />
                <Divider inset={true} insetType="middle" width={5}/>
              </View>
            );
          }) 
        : <Text>Empty Branch</Text>}
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loginBtn: {
    borderRadius: 25,
    height: 50,
    backgroundColor: "#FF1493",
    maxWidth: '100%',
    paddingRight: 30,
  },
  icon: {
    marginLeft: 20,
    marginRight: 5,
  },
  loginText: {
    color: "#fff",
  },  
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color:'#000',
  },
  separator: {
    marginVertical: 30,
    height: 1,
    width: '80%',
    color: '#000',
  },
});

export default AppSelector