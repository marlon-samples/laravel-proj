const tintColorLight = '#fff';
const tintColorDark = '#fff';

export default {
  light: {
    text: '#ac1d53',
    background: '#fff',
    tint: tintColorLight,
    tabIconDefault: '#e33f89',
    tabIconSelected: tintColorLight,
    headerStyleColor: '#e33f89',
  },
  dark: {
    text: '#fff',
    background: '#000',
    tint: tintColorDark,
    tabIconDefault: '#ccc',
    tabIconSelected: tintColorDark,
    headerStyleColor: '#f4511e',
  },
  mecolor: {
    text: '#024c8b',
    background: '#024c8b',
    tint: tintColorDark,
    tabIconDefault: '#ccc',
    tabIconSelected: tintColorDark,
    headerStyleColor: '#f4511e',
  },
};
