const email = 'admin@admin.com';
const password = '1234567';
const sanctum = "1|";
const local = 'http://192.168.110.196:8000';
const production = 'https://xxx.yyyy.com';
const version = '1.0.0 (Beta)';
const company = 'EL Clinic and Beauty Spa';

export default {
  api: {
    local: local,
    production: production,
    version: version,
    company: company,
  },
  credentials: {
    email: email,
    password: password,
  },
  sanctum: {
    var: sanctum,
  },
  currency: {
    peso: 'Php',
    dollar: '$',
  },
}